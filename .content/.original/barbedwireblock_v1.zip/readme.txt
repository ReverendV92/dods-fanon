﻿model: barbedwireblock
entity type: prop_static
directory: props_barbedwire
model 01: barbedwireblock_ok1.mdl
model 02: barbedwireblock_ok2.mdl
model 03: barbedwireblock_broken1.mdl
model 04: barbedwireblock_down_middle.mdl
model 05: barbedwireblock_down_side.mdl
pc 01: lod0=258
pc 02: lod0=258
pc 03: lod0=199
pc 04: lod0=258
pc 05: lod0=258
skin: rusty 512×256
skin: grey 512×256
skin: snowy 512×256
normalmap: no
phong: no
instructions: unpack the materials and models folder to your dod-folder (i.e. c:/programs/steam/steamapps/your@email.com/day of defeat source/dod)

created by pedroleum|at|gmail.com
the content of this file can be used freely in any commercial or non-commercial game. if you wish to make modifications to my work, please contact me at the above mentioned e-mail adress.