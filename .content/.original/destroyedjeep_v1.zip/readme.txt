﻿model: destroyed jeep
entity type: prop_static
directory: props_vehicles
model 01: jeep_us_destroyed1.mdl
pc 01: lod0=6178, lod1=4586, lod2=2739, lod3=1247, lod4=499
skin: destroyed 1024×1024
normalmap: 1024×1024
phong: no
instructions: unpack the materials and models folder to your dod-folder (i.e. c:/programs/steam/steamapps/your@email.com/day of defeat source/dod)

created by valve, modified by pedroleum|at|gmail.com
the content of this file can only be used in day of defeat:source. for any other use, permission has to be given by valve directly.