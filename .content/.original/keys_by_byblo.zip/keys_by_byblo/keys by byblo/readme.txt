﻿

* Original 3D model creation by byblo : http://go.to/byblo


* 3D models creation (and import to SMD) made with kHED: http://khed.glsl.ru/


* Textures creation/adaptation with gimp: http://www.gimp.org/


* License: Please note that everything listed below is copyleft (http://en.wikipedia.org/wiki/Copyleft), free for use and distribute, only with those 3 conditions:

1. Keep the credits references, and the license type MUST remain the same: copyleft.
2. If you want to distribute them, feel free to keep using the [byblo\] folder if you want to, but ONLY if they haven't been MODIFIED in any way (see below).
3. If you want to modify them before distribution (using the source files or hacking the compiled ones), a model or even a single texture's pixel, please DO NOT USE ANYMORE the [byblo\] folders. Just change it to your own taste.


* Some sources are from : http://www.cgtextures.com, adapted by byblo : http://go.to/byblo
For instance:
byblo/decals/sign_toilets01.vtf
byblo/decals/sign_toilets02.vtf
byblo/decals/sign01.vtf
byblo/models/armybarrel.vtf
byblo/models/armybarrel_b.vtf
byblo/models/fusebox.vtf
byblo/models/signs02.vtf
byblo/models/signslum01.vtf


* Thanks to:
http://khed.glsl.ru/ for the great 3D modeling tool: kHED
http://www.gimp.org/ for the separated windows which driving me crazy
http://www.cgtextures.com/ for the textures collection

http://developer.valvesoftware.com/wiki/Main_Page for the comprehensive list
http://www.interlopers.net/ for the good tutorials
http://www.editlife.net for the good tutorials
http://www.logout.fr/hammer for the good tutorials
http://www.halfwit-2.com/ for the good tutorials
http://rvanhoorn.ruhosting.nl/optimization.php for the good tutorials


* Note that some models using HL2 textures directly from GCF files (models which coming with VMT files without their VTF counterpart)
If you want to use those models somewhere else than Source games, first you will have to create you own textures -.-



   enjoy :)

   byblo.

