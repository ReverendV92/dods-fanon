props_bunkers

There is a bunkbed setup (useful for WW2 era bunkers). The bunkbed model is for a DOD:Source beach map I�ve been working on for a while. 

Modeler: Waldo