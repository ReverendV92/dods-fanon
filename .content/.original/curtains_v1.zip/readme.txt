﻿model: curtains
entity type: prop_static
directory: props_windows
model 01: ped_curtains_closed_v1.mdl
model 02: ped_curtains_halfclosed_v1.mdl
model 03: ped_curtains_open_v1.mdl
model 04: ped_curtains_short_v1.mdl
pc 01: lod0=1448, lod1=762, lod2=116
pc 02: lod0=1448, lod1=762, lod2=111
pc 03: lod0=1205, lod1=519, lod2=95
pc 04: lod0=1448, lod1=762, lod2=11
skin: plainwhite 256×512, 64×256
skin: plainblue 256×512, 64×256
skin: plainbeige 256×512, 64×256
skin: redflowers 256×512, 64×256
skin: brownflowers 256×512, 64×256
skin: blueflowers 256×512, 64×256
normalmap: no
phong: no
instructions: unpack the materials and models folder to your dod-folder (i.e. c:/programs/steam/steamapps/your@email.com/day of defeat source/dod)

created by pedroleum|at|gmail.com
the content of this file can be used freely in any commercial or non-commercial game. if you wish to make modifications to my work, please contact me at the above mentioned e-mail adress.