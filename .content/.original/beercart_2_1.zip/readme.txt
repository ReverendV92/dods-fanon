beercart_2_1
------------

Contents:
---------
beercart_2_1: (prop_static) - Is a wooden kart with a wood barrel on it.

Installation:
-------------
model files:  ~username\day of defeat source\dod\models\bone1
material files:  ~username\day of defeat source\dod\materials\models\bone1

Credits:
--------
If you use it credit would be nice.

Model:  Bone
Skin:  ActionJackson @ fnfonline.com

-Enjoy Bone