create a [mod]models/fishy/furniture folder, and place all the contents of the zip file in it. 

all the models use stock hl2 textures, should snap together nicely on a grid setting of 32, and have three LODs

credit for using any of these would be nice.

all rights reserved etc.

fishy   ( guildythefish@hotmail.com )

come visit at www.snarkpit.net