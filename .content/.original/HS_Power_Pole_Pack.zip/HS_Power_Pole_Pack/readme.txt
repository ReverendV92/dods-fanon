HS_Power_Pole_Pack [prop_static]
(HS_PP_Pack just doesn't sound right)
Released: March 15, 2008
-----------------------------------
Installation:

steam/steam apps/(Account Name)/day of defeat source/dod/
-----------------------------------
Credits:
Myself
The many websites dedicated to insulators and other power related utilities.
And VALVe, I used the stock utility pole to get the size right on these.
-----------------------------------
Permission to use for any source mod, just remember to give me credit.
-----------------------------------
email: 
hsedated@yahoo.com