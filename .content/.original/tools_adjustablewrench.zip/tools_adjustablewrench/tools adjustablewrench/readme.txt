Tool Prop models by: Nicholas (Craminator) Fazzoalri :: stiches85@hotmail.com
Compiled: Dec18th 2008


=============================================
Extract into your game root directory with files enabled.
Please credit me if used in your map.
-Prop_static
-Prop_physics
Enjoy.

http://www.nickfmaps.com - Maps Models and more
http://www.nickfmaps.com - Scary things hiding in your closet?
http://www.nickfmaps.com - My Portfolio chegger out :)