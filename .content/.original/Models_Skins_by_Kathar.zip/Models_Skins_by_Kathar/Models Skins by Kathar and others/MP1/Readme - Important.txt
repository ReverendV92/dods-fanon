---Credits---

Glasses:
   Models & Skins by Kathar (Marc Hales)

Syringes:
   Models & Skins by Kathar (Marc Hales)

Horse:
   Photo-Skin from AnimalScience (http://animalscience.ucdavis.edu)
   Model & Skin-editing by Kathar (Marc Hales)

Handcuffs & Key:
   Models & Skins by Kathar (Marc Lyon)

Roulette Table:
   Models & Base-skins by Kathar (Marc Hales)
   Skin-edits by Waxx

Pistol Magazines:
   Models & Skins by Kathar (Marc Hales)

German Spade:
   Models & Skins by Kathar (Marc Hales)

Flags:
   Models by Kathar (Marc Hales)
   Skins by Shadow7 (Freelancer) & Kathar (Marc Hales)


---GMod9 Installation---

Copy the 'materials', 'models' and any other folders that are included in this zip to: "...SteamApps\SourceMods\gmod\"
For eg. "C:\Program Files\Valve\Steam\SteamApps\SourceMods\gmod\"


Now, add these lines-:

	"~Model Pack 1"			""
	"#Horse Bridle"				"models/katharsmodels/animals/horse/HorseBrown-1.mdl"
	"#Horse"				"models/katharsmodels/animals/horse/HorseBrown-2.mdl"
	"Handcuffs-Closed"			"models/katharsmodels/handcuffs/handcuffs-1.mdl"
	"Handcuffs-Half"			"models/katharsmodels/handcuffs/handcuffs-2.mdl"
	"Handcuffs-Open"			"models/katharsmodels/handcuffs/handcuffs-3.mdl"
	"Key"					"models/katharsmodels/key/key.mdl"
	"Syringe Empty"				"models/katharsmodels/syringe_in/syringe_in.mdl"
	"Syringe Full"				"models/katharsmodels/syringe_out/syringe_out.mdl"
	"Glasses 1"				"models/katharsmodels/glasses-1/glasses-1.mdl"
	"Glasses 2"				"models/katharsmodels/glasses-2/glasses-2.mdl"
	"Glasses 2-2"				"models/katharsmodels/glasses-2-2/glasses-2-2.mdl"
	"DEmagazine 1-1"			"models/katharsmodels/magazines/DEmagazine1/DEmagazine1.mdl"
	"DEmagazine 1-2"			"models/katharsmodels/magazines/DEmagazine3/DEmagazine3.mdl"
	"DEmagazine 2-1"			"models/katharsmodels/magazines/DEmagazine2/DEmagazine2.mdl"
	"DEmagazine 2-2"			"models/katharsmodels/magazines/DEmagazine4/DEmagazine4.mdl"
	".50 AE Bullet"				"models/katharsmodels/bullets/50AE/50AE.mdl"
	"Roulette Wheel"			"models/katharsmodels/roulettewheel/roulettewheel.mdl"
	"Roulette Ball"				"models/katharsmodels/roulettewheel/rouletteball.mdl"
	"Gman's Briefcase"			"models/katharsmodels/gmanbriefcase/gmanbriefcase.mdl"
	"German Spade"				"models/katharsmodels/german-spade/german-spade.mdl"
	"Great Britain"				"models/katharsmodels/flags/flag02.mdl"
	"France"				"models/katharsmodels/flags/flag03.mdl"
	"USA"					"models/katharsmodels/flags/flag04.mdl"
	"Japan"					"models/katharsmodels/flags/flag05.mdl"
	"Germany"				"models/katharsmodels/flags/flag09.mdl"
	"Canada"				"models/katharsmodels/flags/flag10.mdl"
	"England"				"models/katharsmodels/flags/flag11.mdl"
	"Netherlands"				"models/katharsmodels/flags/flag12.mdl"
	"Sweden"				"models/katharsmodels/flags/flag13.mdl"
	"Australia"				"models/katharsmodels/flags/flag14.mdl"
	"EU"					"models/katharsmodels/flags/flag15.mdl"
	"Finland"				"models/katharsmodels/flags/flag16.mdl"
	"Norway"				"models/katharsmodels/flags/flag17.mdl"
	"Turkey"				"models/katharsmodels/flags/flag24.mdl"
	"China"					"models/katharsmodels/flags/flag25.mdl"
	"Denmark"				"models/katharsmodels/flags/flag26.mdl"
	"Egypt"					"models/katharsmodels/flags/flag27.mdl"
	"Macedonia"				"models/katharsmodels/flags/flag18.mdl"
	"Russian Federation"			"models/katharsmodels/flags/flag19.mdl"
	"Puerto Rico"				"models/katharsmodels/flags/flag32.mdl"
	"Slovenia"				"models/katharsmodels/flags/flag35.mdl"
	"Scotland"				"models/katharsmodels/flags/flag36.mdl"
	"USSR"					"models/katharsmodels/flags/flag01.mdl"
	"Combine"				"models/katharsmodels/flags/flag06.mdl"
	"Rebels"				"models/katharsmodels/flags/flag07.mdl"
	"Surrender"				"models/katharsmodels/flags/flag08.mdl"
	"Jolly Roger"				"models/katharsmodels/flags/flag20.mdl"
	"Blue Team"				"models/katharsmodels/flags/flag21.mdl"
	"Red Team"				"models/katharsmodels/flags/flag22.mdl"
	"All Your Base"				"models/katharsmodels/flags/flag23.mdl"
	"Firefox"				"models/katharsmodels/flags/flag28.mdl"
	"Internet Explorer"			"models/katharsmodels/flags/flag29.mdl"
	"PHWonline"				"models/katharsmodels/flags/flag30.mdl"
	"Facepunch"				"models/katharsmodels/flags/flag31.mdl"
	"Blue Hammer"				"models/katharsmodels/flags/flag33.mdl"
	"Q2 CTF Symbol"				"models/katharsmodels/flags/flag34.mdl"


-to whichever spawn menu you like.
For eg. "C:\Program Files\Valve\Steam\SteamApps\SourceMods\gmod\settings\menu_props\random_crap.txt"
Make sure you add the lines after the '{' symbol, but before the '}'.



---Retail GMod (10) Installation---

Copy the "materials", "models" and any other folders, that are included in this zip, to: "...SteamApps\(UsernameHere)\garrysmod\garrysmod\"
For eg. "C:\Program Files\Valve\Steam\SteamApps\steam_user123\garrysmod\garrysmod\"

Now, load up GMod (10) and open up the 'Q' menu. On the left, you will see a folder/file icon. Click it.
You now double-click on the "Root" button. And then, double-click "garrysmod", followed by "katharsmodels".
From there, enter any sub-folder you fancy, right-click on any '.mdl' file and add it to whichever spawn menu you like.



---Terms & Conditions---

1.) Reskinning of these models is allowed, so long as it "clearly" states I created these models.

2.) Do not release these models claiming that you created them.

3.) No need to ask to stick these models into model packs, as i would happy if someone even wanted to.



	Thanks for downloading. visit www.kathar.net for more models by myself, Kathar.