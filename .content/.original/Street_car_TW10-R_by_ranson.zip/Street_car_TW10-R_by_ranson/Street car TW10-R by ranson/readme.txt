Info from the release thread...
http://forums.steampowered.com/forums/showthread.php?t=1119719

Hey guys,

for what I've seen the old threads vanished, so here are new and working links to the models I've released for DoD:S so far plus a new addition. Not sure if it's of any use anymore, haven't seen that many new custom maps lately. But then again it doesn't cost me anything, since it's a model I made for RnL originally.

Street car TW10-R

Doors are separated from the actual model, cause of transparency sorting issues. Use them with care, maybe you're lucky.

Download:
http://download.ranson.at/ranson_tram.zip