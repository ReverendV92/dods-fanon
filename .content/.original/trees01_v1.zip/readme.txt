﻿model: trees
entity type: prop_static / prop_dynamic
directory: props_foliage

static models:
model 01: ped_tree01_leaves_green.mdl
model 02: ped_tree01_leaves_autumn01.mdl
model 03: ped_tree01_leaves_autumn02.mdl
model 04: ped_tree01_branches.mdl
model 05: ped_tree01_branches_winter.mdl

dynamic models: (animated)
model 06: ped_tree01_anim_leaves_green.mdl / lod0=186
model 07: ped_tree01_anim_leaves_autumn01.mdl / lod0=132
model 08: ped_tree01_anim_leaves_autumn02.mdl / lod0=70
model 09: ped_tree01_anim_branches.mdl / lod0=68
model 10: ped_tree01_anim_branches_winter.mdl / lod0=58

lods for all models: lod0=846, lod1=629, lod2=258, lod3=194

skin: green leafs 512×512, bark 256×512
skin: autumn 01 512×512, bark 256×512
skin: autumn 02 512×512, bark 256×512
skin: branches 512×512, bark 256×512
skin: branches winter 512×512, bark winter 256×512
normalmap: yes
phong: no
instructions: unpack the materials and models folder to your dod-folder (i.e. c:/programs/steam/steamapps/your@email.com/day of defeat source/dod)

created by pedroleum|at|gmail.com
the content of this file can be used freely in any commercial or non-commercial game. if you wish to make modifications to my work, please contact me at the above mentioned e-mail adress.