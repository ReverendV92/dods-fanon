﻿model: tnt crates
entity type: prop_static
directory: props_crates
model 01: tnt_crate_ok01.mdl
model 02: tnt_crate_open01.mdl
model 03: tnt_crate_destroyed01.mdl
model 04: tnt_crate_destroyed02.mdl
pc 01: lod0=248
pc 02: lod0=462
pc 03: lod0=592
pc 04: lod0=615
skin: uses default tnt dump texture
normalmap: no
phong: no
instructions: unpack the models folder to your dod-folder (i.e. c:/programs/steam/steamapps/your@email.com/day of defeat source/dod)

created by valve, modified by pedroleum|at|gmail.com
the content of this file can only be used in day of defeat:source. for any other use, permission has to be given by valve directly.