Wicked Obstacles Version 1

These are beach obstacles for use in Day of Defeat: Source maps

To install unzip to your  C:\Program Files\Steam\SteamApps\charlestonn\day of defeat source\dod\models  directory

Author: Someth|ng W|cked