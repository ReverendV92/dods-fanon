****************************************

	European Tree Pack	

	For Day Of Defeat: Source

****************************************

---
Author: Berghoff
---
Website: www.ofpc.de/berghoff
---

Contact:
PM @ http://www.dayofdefeat.net/forums/index.php

Ideas or constructive criticism? Post in topic! ;)
---
Credits:

- Jed (for GUIStudioMDL and info)
- Nem's Tools (for various texture tools)
- People who posted in forum (For helping me out with nagging problems)
- Various tree books/websites

---
Version: Release 4

Most bugs should be removed by now..
---

Usage: These are models for Source maps.

---

Installation: Extract contents of "dod" folder to  \Steam\SteamApps\<YOURACCOUNTNAME>\day of defeat source\

Models in hammer editor can be found in the brg_foliage folder

---

Features:

- 1 Linden Tree
- 1 Alder Tree + Skybox model
- 2 Scots Pines
- 1 Oak Tree + Skybox model
- 1 Birch Tree + Skybox model
- 1 Oak Shrub
- 1 Oriental Pine
- 1 useless oak branch :)

---

Changelog:

- Release #4:

* changed:
	- added tree_orientalpine1.mdl
	- changed collision for birch tree
	- removed collisions for skybox models
	- resized textures to 512x512

- Release #3:

* added:- tree_oak1.mdl
	- tree_birch1.mdl
	- object_oakbranch1.mdl
	- tree_oak1_skybox.mdl
	- tree_oak1_skyboxfar.mdl
	- shrub_oak1.mdl

- Release #2:


* added:- tree_scotspine1.mdl
	- tree_scotspine2.mdl

* changed: tree_alder.mdl:
	- Changed UV mapping
	- Added extra LOD
	- collision model
	- Optimized model
	- Removed skins

* changed: tree_commonlinden_1.mdl:
	- collision model

- First Release
---

This is a free addon, this package must remain unmodified. Do not sell this addon.
Only for use in Source. You may freely use models/textures in this pack for own projects/mods in Source only if proper credits are given.

Now go hug some trees ;)