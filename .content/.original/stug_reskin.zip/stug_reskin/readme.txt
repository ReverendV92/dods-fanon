﻿material: stug reskin
directory: props_vehicles
skin: grey 2048×1024
skin: yellowgreen 2048×1024
normalmap: 1024×512
phong: no
instructions: unpack the materials folder to your dod-folder (i.e. c:/programs/steam/steamapps/your@email.com/day of defeat source/dod)
there are two versions of the skin. default is grey. for the yellow-greenish version open the vmt-file with a text editor and change the line for the base-texture like stated there.

original model and texture by lard, reskin by pedroleum|at|gmail.com
the content of this file can only be used in day of defeat:source. for any other use, permission has to be given by lard directly.