cherokemodels foliage, Palms, Bananas, small ferns, clumps of bamboo and a lever road block.

custom foliage,  by the cheroke team
website: http://www.cheroketeam.savana.cz

The team is not around anymore, this link around AUGUST 2006 is a back-up when the site died...
http://web.archive.org/web/20060426205601/http://www.cheroketeam.savana.cz/

Members were...
Pavel �Cheroke� Turzo
Mari�n �P3PO� Kovanic
Miroslav �mirek� Svoboda
Vitek �kalisto� Barabas
Ali �sm0k3y� Hill
Kamil �tutor / Kamil� Janda

