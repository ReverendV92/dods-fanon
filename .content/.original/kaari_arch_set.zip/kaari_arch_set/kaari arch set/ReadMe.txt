﻿This prop is created by Deadity.  deadity@mail.com
----------------------------


------INSTALLATION-----------------------
Extract these files to "C:\Games\Steam\SteamApps\(username)\half-life 2\hl2"

kaari.vmf is a Valve Map File that contains this arch and a 
way to implement it in a wall.
----------------------------------------------------------------------

If you use this prop in any of your work remember to give me credit. 
No need to ask for permission.

If you need the source models and textures for this prop, throw me a mail.