Ricochet's Prop Pack
====================

13. March 2006


Here's a collection of various props. Feel free to use them in your maps. Credit is appreciated :)


Contents:
=========

* rc_barbwire: a barb wire model. Needs to be clipped as it's intangible. Static prop.
* rc_chapel: A small decorative chapel. Static prop.
* rc_drawerchest: A chest of drawers. Physics prop.
* rc_feeder: A triangular cattle feeder thingy. One normal and one snow skin. Static prop.
* rc_milkcan: A metal milk can. Physics prop.
* rc_phonepole: A different type of telephone pole. One normal and one snow skin. Static prop.
* rc_stumpaxe: a log with an axe stuck in it. Physics prop.
* rc_trough: A wooden trough. One normal and one snow skin. Static prop.
* rc_well: a covered well. Static prop.



Installation:
=============

Unzip these files into your 

D:\Steam\SteamApps\email@mail.com\day of defeat source\dod directory.

The .VMTs and .VTFs should go in 
...\dod\materials\models\Ricochet\ 

and the rest into 
...\dod\models\Ricochet\

Have fun.
Ricochet