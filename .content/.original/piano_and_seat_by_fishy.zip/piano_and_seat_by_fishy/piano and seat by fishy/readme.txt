original model by fisheye, aka fishy


feel free to use for personnal projects, but dont package or distribute as a default models for any mods without my permission. 

any rights that valve have left me, are reserved by me, fisheye, thank you very much.

fishy@invalid-brush.co.uk
