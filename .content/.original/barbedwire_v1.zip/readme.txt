﻿model: barbedwire
entity type: prop_static
directory: props_barbedwire
model 01: barbedwire_cross01.mdl
model 02: barbedwire_high01.mdl
pc 01: lod0=520, lod1=304
pc 02: lod0=136
skin: 256×256, 128×128
normalmap: no
phong: no
instructions: unpack the materials and models folder to your dod-folder (i.e. c:/programs/steam/steamapps/your@email.com/day of defeat source/dod)

created by pedroleum|at|gmail.com
the content of this file can be used freely in any commercial or non-commercial game. if you wish to make modifications to my work, please contact me at the above mentioned e-mail adress.