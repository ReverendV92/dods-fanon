---Credits---

Models by Kathar (Marc Hales)
Skins by Valve
Beta tested by xtjmanxt


---GMod9 Installation---

Copy the 'materials', 'models' and any other folders that are included in this zip to: "...SteamApps\SourceMods\gmod\"
For eg. "C:\Program Files\Valve\Steam\SteamApps\SourceMods\gmod\"


Now, add these lines-:

	"Dest. House"				"models\katharsmodels\dynamic\houses\house-1\house.mdl"

-to whichever spawn menu you like.
For eg. "C:\Program Files\Valve\Steam\SteamApps\SourceMods\gmod\settings\menu_props\random_crap.txt"
Make sure you add the lines after the '{' symbol, but before the '}'.



---Retail GMod (10) Installation---

Copy the "materials", "models" and any other folders, that are included in this zip, to: "...SteamApps\(UsernameHere)\garrysmod\garrysmod\"
For eg. "C:\Program Files\Valve\Steam\SteamApps\steam_user123\garrysmod\garrysmod\"

Now, load up GMod (10) and open up the 'Q' menu. On the left, you will see a folder/file icon. Click it.
You now double-click on the "Root" button. And then, double-click "garrysmod", followed by "katharsmodels".
From there, enter any sub-folder you fancy, right-click on any '.mdl' file and add it to whichever spawn menu you like.



---Terms & Conditions---

1.) Reskinning of these models is allowed, so long as it "clearly" states I created these models.

2.) Do not release these models claiming that you created them.

3.) No need to ask for permission to stick these models into model packs. Just please provide a link to my website, credit me, or something similar.



	Thanks for downloading. visit www.kathar.net for more models by myself, Kathar.