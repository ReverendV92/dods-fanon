﻿model: minesigns
entity type: prop_static
directory: props_signs
model 01: minesign_[skinname].mdl
model 02: minesign_broken01_[skinname].mdl
model 03: minesign_small01_[skinname].mdl
pc 01: lod0=216, lod1=71
pc 02: lod0=216, lod1=128
pc 03: lod0=216, lod1=67
skin: black 256×512*
skin: blackwood 256×512*
skin: red 128×128*
skin: redwhite 128×128*
skin: redwhite2 128×128*
normalmap: no
phong: no
instructions: unpack the materials and models folder to your dod-folder (i.e. c:/programs/steam/steamapps/your@email.com/day of defeat source/dod)

* higher resolution textures included

created by pedroleum|at|gmail.com
the content of this file can be used freely in any commercial or non-commercial game. if you wish to make modifications to my work, please contact me at the above mentioned e-mail adress.