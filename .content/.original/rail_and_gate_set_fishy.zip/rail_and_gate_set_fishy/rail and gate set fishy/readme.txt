
use the wizard to unzip to your mods root folder.


all models by fisheye, aka fishy

fishy@invalid-brush.co.uk


feel free to use these for personnal projects, but dont package or distribute them as default models for any mods without my permission. 

all rights reserved by me, fishy, thank you very much.

